//
//  ViewController.swift
//  foodrec
//
//  Created by Gugulavath prashanth kumar on 29/03/21.
//

import UIKit

class ViewController: UIViewController {
    
    var dataTaskObj:URLSessionDataTask!
    var urlReq:URLRequest!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        getData()
        
        

    }
  

        
        
        
        
        
    }




